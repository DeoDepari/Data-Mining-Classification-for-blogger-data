# -*- coding: utf-8 -*-
"""
Created on Mon Jun  1 18:27:31 2020

@author: irzar
"""

import pandas as pd
from sklearn.cluster import KMeans
from sklearn import metrics
import numpy as np
import matplotlib.pyplot as plt
from sklearn import preprocessing

names = ['degree','caprice','topic','lmt','lpss','pb']
data = pd.read_csv("kohkiloyeh.csv", names=names)

degrees = data['degree']
caprices= data['caprice']
topics = data['topic']
lmts = data['lmt']
lpsss = data['lpss']
pbs = data['pb']

le = preprocessing.LabelEncoder()
dg_en = le.fit_transform(degrees)
#high=0;low=1;med=2
cp_en = le.fit_transform(caprices)
#left=0;middle=1;rigth=2
tp_en = le.fit_transform(topics)
#impression=0;news=1;political=2;scientific=3;tourism=4
lmt_en = le.fit_transform(lmts)
#no=0;yes=1
lpss_en = le.fit_transform(lpsss)
#no=0;yes=1
pb_en = le.fit_transform(pbs)
fitur_gabung = np.array([dg_en,cp_en,tp_en,lmt_en,lpss_en])


for i in range(2,37):
    df = np.ndarray.transpose(fitur_gabung)
    kmeans = KMeans(n_clusters=i)
    kmeans.fit(df)
    labels = kmeans.labels_
    CHindex = metrics.calinski_harabasz_score(df, labels)
    print("CH Index untuk k = ",i," = ",CHindex)
    
    label_asli = pb_en
    label_prediksi = labels
    FMI = metrics.fowlkes_mallows_score(label_asli, label_prediksi)
    print("FMI untuk      k = ",i,' = ', FMI)
    
    print()